export class annoucementsModels {
    announcementId: number;
    merchantStoreId: number;
    customerType: string;
    title: string;
    content: number;
    status: string;
    createdAt: string;    
  
  }
  
export class StylistPermission {
    permissionId: any;
    name: any;
    constructor(){
        this.permissionId = "";
        this.name = "";
    }
}
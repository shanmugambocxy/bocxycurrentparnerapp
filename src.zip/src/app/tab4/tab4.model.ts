export class MerchantCustomerService {
    merchantStoreId: number;
    customerId: number;
    visitCount: string;
    lastVisitTime: string;
    mobileNo: number;
    firstName: string;
    lastName: string;    
  
  }
  
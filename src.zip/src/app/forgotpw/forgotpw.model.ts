export class AccountSecurityQuestions {
  questionId: number;
  question: string;
  active: string;
}

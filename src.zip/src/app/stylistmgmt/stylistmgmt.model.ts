export class Stylist {
  accountId: number;
  firstName: string;
  isOpen: boolean;
}

export class Holiday {
  merchantHolidayId: number;
  name: string;
}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usermanual',
  templateUrl: './usermanual.page.html',
  styleUrls: ['./usermanual.page.scss'],
})
export class UsermanualPage implements OnInit {

  constructor() { }

  ngOnInit() { }


}


export class Slotduration {
  constructor() { }
  name: string;
  openingTime: string;
  closingTime: string;
  weekdayFlag: string;
  weekdays: any[];
}

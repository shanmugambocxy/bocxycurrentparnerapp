export class SlotInputTime {
  name: string;
  startDate: string;
  endDate: string;
  openingTime: string;
  closingTime: string;
  slotGroupId: number;
  merchantSlotId: number;
  merchantSpecialSlotId: number;
}

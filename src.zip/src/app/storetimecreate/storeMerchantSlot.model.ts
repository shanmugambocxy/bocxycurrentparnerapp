export class MerchantSpecialSlot {
  slotGroupId: number;
  startDate: string;
  endDate: string;
  name: string;
  openingTime: string;
  closingTime: string;
}

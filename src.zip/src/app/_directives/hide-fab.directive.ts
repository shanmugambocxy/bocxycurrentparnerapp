import { Directive } from '@angular/core';

@Directive({
  selector: '[appHideFab]'
})
export class HideFabDirective {

  constructor() { }

}

import { HideFabDirective } from './hide-fab.directive';

describe('HideFabDirective', () => {
  it('should create an instance', () => {
    const directive = new HideFabDirective();
    expect(directive).toBeTruthy();
  });
});

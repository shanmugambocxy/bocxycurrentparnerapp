import { HideOnScrollDirective } from './hide-on-scroll.directive';

describe('HideOnScrollDirective', () => {
  it('should create an instance', () => {
    const directive = new HideOnScrollDirective();
    expect(directive).toBeTruthy();
  });
});

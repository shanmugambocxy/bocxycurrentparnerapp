export class StoreTypesList {
    storeTypeId: number;
    type: string;
}
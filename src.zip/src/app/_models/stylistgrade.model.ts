export class StylistGrade{
    professionistGradeId:number;
    name:string;
    isChecked?:boolean;
    active:string;
}
export class Token {
  accessToken: string;
}
export class Account {
  mobileNo: string;
  mobileNoDialCode: string;
  // roleCode: string;
  roleCodes: string[];
  active: string;
}

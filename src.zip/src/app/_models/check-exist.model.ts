export class CheckExistMobile {
  exist: boolean;
}

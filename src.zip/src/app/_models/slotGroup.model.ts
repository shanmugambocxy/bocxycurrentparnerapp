export class SlotGroup {
  slotGroupId: Number;
  name: string;
  minutes: number;
}

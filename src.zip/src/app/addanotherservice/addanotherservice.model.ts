export class ServiceDetails {
  appointment_id: number;
  merchant_store_service_id: number;
  professionist_account_id: number;
}
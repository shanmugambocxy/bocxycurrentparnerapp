export class TimeSlot {
  slotName: string;
  isDisabled?: boolean = true;
}
export class MerchantService{
    merchantStoreServiceId: number;
    name:string;
}
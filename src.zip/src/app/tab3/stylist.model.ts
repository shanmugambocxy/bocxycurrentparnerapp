export class Stylist{
    professionistAccountId:number;
    firstName:string;
}
export class MerchantHoliday {
  merchantHolidayId: number;
  name: string;
  description: string;
  holidayType: string;
  repeatType: string;
  dateType: string;
  startDate: string;
  endDate: string;
  startDay: string;
  endDay: string;
  active: string;
}
